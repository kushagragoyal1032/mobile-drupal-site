// const datas = document.querySelectorAll('.carousel-inner .views-row');
// // console.log(datas);

// for (const data of datas) {
//     data.classList.add('carousel-item');
// }

// datas[0].classList.add('active');
// console.log(datas[0]);